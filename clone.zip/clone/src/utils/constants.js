export const PYTHON = "python";     
export const WEB_DEVELOPMENT = "web development";
export const DATA_SCIENCE = "data science";
export const AWS = "aws";
export const DESIGN = "design";
export const MARKETING = "marketing";
