import Home from"./HomePage";
import Courses from "./CoursesPage";
import SingleCourse from "./SingleCoursePage";
import Cart from "./CartPage";

export {Home, Courses, SingleCourse, Cart};